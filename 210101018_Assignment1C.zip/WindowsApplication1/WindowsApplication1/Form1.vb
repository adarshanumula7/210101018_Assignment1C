﻿Imports System.Data

Public Class SimpleCalculator
    ' Variable to store the current mathematical expression entered by the user
    Dim currentExpression As String = ""

    ' Handles the click event for digit buttons (0-9) and the decimal point
    Private Sub DigitButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDigit0.Click, btnDigit1.Click, btnDigit2.Click, btnDigit3.Click, btnDigit4.Click, btnDigit5.Click, btnDigit6.Click, btnDigit7.Click, btnDigit8.Click, btnDigit9.Click, btnDot.Click
        Dim button As Button = CType(sender, Button)
        ' Appends the clicked button's text to the current expression
        currentExpression = currentExpression + button.Text
        ' Updates the display to show the modified expression
        UpdateDisplay()
    End Sub

    ' Handles the click event for operator buttons (+, -, *, /)
    Private Sub OperatorButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click, btnSubtract.Click, btnMultiply.Click, btnDivide.Click
        Dim button As Button = CType(sender, Button)
        ' Appends the clicked operator to the current expression with spaces for better formatting
        currentExpression = currentExpression + " " & button.Text & " "
        ' Updates the display to show the modified expression
        UpdateDisplay()
    End Sub

    ' Handles the click event for the "Equals" button
    Private Sub btnEquals_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnEquals.Click
        ' Invokes the EvaluateExpression method to calculate the result of the entered expression
        EvaluateExpression()
    End Sub

    ' Handles the click event for the "Clear" button
    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        ' Resets the current expression
        currentExpression = ""
        ' Updates the display to show the cleared expression
        UpdateDisplay()
    End Sub

    ' Handles the click event for the "Backspace" button
    Private Sub btnBackspace_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnBackspace.Click
        ' Checks if the current expression is not empty before removing the last character
        If currentExpression.Length > 0 Then
            ' Removes the last character from the current expression
            currentExpression = currentExpression.Substring(0, currentExpression.Length - 1)
            ' Updates the display to show the modified expression
            UpdateDisplay()
        End If
    End Sub

    ' Attempts to evaluate the current expression and update the display with the result
    Private Sub EvaluateExpression()
        Try
            ' Uses DataTable's Compute method to evaluate the expression
            Dim result As Object = New DataTable().Compute(currentExpression, Nothing)
            ' Updates the current expression with the result
            currentExpression = result.ToString()
            ' Updates the display to show the result
            UpdateDisplay()
        Catch ex As Exception
            ' Displays an error message for invalid expressions
            MessageBox.Show("Invalid expression", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' Clears the current expression
            currentExpression = ""
            ' Updates the display to show the cleared expression
            UpdateDisplay()
        End Try
    End Sub

    ' Updates the calculator display with the current expression
    Private Sub UpdateDisplay()
        ' Sets the text property of the display textbox to the current expression
        txtDisplay.Text = currentExpression
    End Sub

End Class

