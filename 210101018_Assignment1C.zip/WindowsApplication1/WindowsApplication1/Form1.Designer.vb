﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SimpleCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnDigit7 = New System.Windows.Forms.Button()
        Me.btnDigit4 = New System.Windows.Forms.Button()
        Me.btnBackspace = New System.Windows.Forms.Button()
        Me.btnDivide = New System.Windows.Forms.Button()
        Me.btnDigit8 = New System.Windows.Forms.Button()
        Me.btnDigit9 = New System.Windows.Forms.Button()
        Me.btnDigit5 = New System.Windows.Forms.Button()
        Me.btnDigit6 = New System.Windows.Forms.Button()
        Me.btnMultiply = New System.Windows.Forms.Button()
        Me.btnEquals = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnDigit0 = New System.Windows.Forms.Button()
        Me.btnDot = New System.Windows.Forms.Button()
        Me.btnDigit1 = New System.Windows.Forms.Button()
        Me.btnDigit2 = New System.Windows.Forms.Button()
        Me.btnDigit3 = New System.Windows.Forms.Button()
        Me.btnSubtract = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtDisplay
        '
        Me.txtDisplay.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtDisplay.Location = New System.Drawing.Point(19, 18)
        Me.txtDisplay.Margin = New System.Windows.Forms.Padding(5)
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.ReadOnly = True
        Me.txtDisplay.Size = New System.Drawing.Size(230, 34)
        Me.txtDisplay.TabIndex = 0
        Me.txtDisplay.Text = "0"
        Me.txtDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(19, 58)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(50, 50)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "C"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnDigit7
        '
        Me.btnDigit7.Location = New System.Drawing.Point(19, 118)
        Me.btnDigit7.Name = "btnDigit7"
        Me.btnDigit7.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit7.TabIndex = 2
        Me.btnDigit7.Text = "7"
        Me.btnDigit7.UseVisualStyleBackColor = True
        '
        'btnDigit4
        '
        Me.btnDigit4.Location = New System.Drawing.Point(19, 178)
        Me.btnDigit4.Name = "btnDigit4"
        Me.btnDigit4.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit4.TabIndex = 3
        Me.btnDigit4.Text = "4"
        Me.btnDigit4.UseVisualStyleBackColor = True
        '
        'btnBackspace
        '
        Me.btnBackspace.Location = New System.Drawing.Point(79, 58)
        Me.btnBackspace.Name = "btnBackspace"
        Me.btnBackspace.Size = New System.Drawing.Size(50, 50)
        Me.btnBackspace.TabIndex = 4
        Me.btnBackspace.Text = "<"
        Me.btnBackspace.UseVisualStyleBackColor = True
        '
        'btnDivide
        '
        Me.btnDivide.Location = New System.Drawing.Point(139, 58)
        Me.btnDivide.Name = "btnDivide"
        Me.btnDivide.Size = New System.Drawing.Size(50, 50)
        Me.btnDivide.TabIndex = 5
        Me.btnDivide.Text = "/"
        Me.btnDivide.UseVisualStyleBackColor = True
        '
        'btnDigit8
        '
        Me.btnDigit8.Location = New System.Drawing.Point(79, 118)
        Me.btnDigit8.Name = "btnDigit8"
        Me.btnDigit8.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit8.TabIndex = 6
        Me.btnDigit8.Text = "8"
        Me.btnDigit8.UseVisualStyleBackColor = True
        '
        'btnDigit9
        '
        Me.btnDigit9.Location = New System.Drawing.Point(139, 118)
        Me.btnDigit9.Name = "btnDigit9"
        Me.btnDigit9.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit9.TabIndex = 7
        Me.btnDigit9.Text = "9"
        Me.btnDigit9.UseVisualStyleBackColor = True
        '
        'btnDigit5
        '
        Me.btnDigit5.Location = New System.Drawing.Point(79, 178)
        Me.btnDigit5.Name = "btnDigit5"
        Me.btnDigit5.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit5.TabIndex = 8
        Me.btnDigit5.Text = "5"
        Me.btnDigit5.UseVisualStyleBackColor = True
        '
        'btnDigit6
        '
        Me.btnDigit6.Location = New System.Drawing.Point(139, 178)
        Me.btnDigit6.Name = "btnDigit6"
        Me.btnDigit6.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit6.TabIndex = 9
        Me.btnDigit6.Text = "6"
        Me.btnDigit6.UseVisualStyleBackColor = True
        '
        'btnMultiply
        '
        Me.btnMultiply.Location = New System.Drawing.Point(199, 58)
        Me.btnMultiply.Name = "btnMultiply"
        Me.btnMultiply.Size = New System.Drawing.Size(50, 50)
        Me.btnMultiply.TabIndex = 10
        Me.btnMultiply.Text = "*"
        Me.btnMultiply.UseVisualStyleBackColor = True
        '
        'btnEquals
        '
        Me.btnEquals.Location = New System.Drawing.Point(199, 118)
        Me.btnEquals.Name = "btnEquals"
        Me.btnEquals.Size = New System.Drawing.Size(50, 50)
        Me.btnEquals.TabIndex = 11
        Me.btnEquals.Text = "="
        Me.btnEquals.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(199, 238)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(50, 110)
        Me.btnAdd.TabIndex = 12
        Me.btnAdd.Text = "+"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnDigit0
        '
        Me.btnDigit0.Location = New System.Drawing.Point(19, 298)
        Me.btnDigit0.Name = "btnDigit0"
        Me.btnDigit0.Size = New System.Drawing.Size(110, 50)
        Me.btnDigit0.TabIndex = 13
        Me.btnDigit0.Text = "0"
        Me.btnDigit0.UseVisualStyleBackColor = True
        '
        'btnDot
        '
        Me.btnDot.Location = New System.Drawing.Point(139, 298)
        Me.btnDot.Name = "btnDot"
        Me.btnDot.Size = New System.Drawing.Size(50, 50)
        Me.btnDot.TabIndex = 14
        Me.btnDot.Text = "."
        Me.btnDot.UseVisualStyleBackColor = True
        '
        'btnDigit1
        '
        Me.btnDigit1.Location = New System.Drawing.Point(19, 238)
        Me.btnDigit1.Name = "btnDigit1"
        Me.btnDigit1.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit1.TabIndex = 15
        Me.btnDigit1.Text = "1"
        Me.btnDigit1.UseVisualStyleBackColor = True
        '
        'btnDigit2
        '
        Me.btnDigit2.Location = New System.Drawing.Point(79, 238)
        Me.btnDigit2.Name = "btnDigit2"
        Me.btnDigit2.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit2.TabIndex = 16
        Me.btnDigit2.Text = "2"
        Me.btnDigit2.UseVisualStyleBackColor = True
        '
        'btnDigit3
        '
        Me.btnDigit3.Location = New System.Drawing.Point(139, 238)
        Me.btnDigit3.Name = "btnDigit3"
        Me.btnDigit3.Size = New System.Drawing.Size(50, 50)
        Me.btnDigit3.TabIndex = 17
        Me.btnDigit3.Text = "3"
        Me.btnDigit3.UseVisualStyleBackColor = True
        '
        'btnSubtract
        '
        Me.btnSubtract.Location = New System.Drawing.Point(199, 178)
        Me.btnSubtract.Name = "btnSubtract"
        Me.btnSubtract.Size = New System.Drawing.Size(50, 50)
        Me.btnSubtract.TabIndex = 18
        Me.btnSubtract.Text = "-"
        Me.btnSubtract.UseVisualStyleBackColor = True
        '
        'SimpleCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Purple
        Me.ClientSize = New System.Drawing.Size(266, 365)
        Me.Controls.Add(Me.btnSubtract)
        Me.Controls.Add(Me.btnDigit3)
        Me.Controls.Add(Me.btnDigit2)
        Me.Controls.Add(Me.btnDigit1)
        Me.Controls.Add(Me.btnDot)
        Me.Controls.Add(Me.btnDigit0)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.btnEquals)
        Me.Controls.Add(Me.btnMultiply)
        Me.Controls.Add(Me.btnDigit6)
        Me.Controls.Add(Me.btnDigit5)
        Me.Controls.Add(Me.btnDigit9)
        Me.Controls.Add(Me.btnDigit8)
        Me.Controls.Add(Me.btnDivide)
        Me.Controls.Add(Me.btnBackspace)
        Me.Controls.Add(Me.btnDigit4)
        Me.Controls.Add(Me.btnDigit7)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.txtDisplay)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SimpleCalculator"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtDisplay As System.Windows.Forms.TextBox
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnDigit7 As System.Windows.Forms.Button
    Friend WithEvents btnDigit4 As System.Windows.Forms.Button
    Friend WithEvents btnBackspace As System.Windows.Forms.Button
    Friend WithEvents btnDivide As System.Windows.Forms.Button
    Friend WithEvents btnDigit8 As System.Windows.Forms.Button
    Friend WithEvents btnDigit9 As System.Windows.Forms.Button
    Friend WithEvents btnDigit5 As System.Windows.Forms.Button
    Friend WithEvents btnDigit6 As System.Windows.Forms.Button
    Friend WithEvents btnMultiply As System.Windows.Forms.Button
    Friend WithEvents btnEquals As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnDigit0 As System.Windows.Forms.Button
    Friend WithEvents btnDot As System.Windows.Forms.Button
    Friend WithEvents btnDigit1 As System.Windows.Forms.Button
    Friend WithEvents btnDigit2 As System.Windows.Forms.Button
    Friend WithEvents btnDigit3 As System.Windows.Forms.Button
    Friend WithEvents btnSubtract As System.Windows.Forms.Button

    
End Class
